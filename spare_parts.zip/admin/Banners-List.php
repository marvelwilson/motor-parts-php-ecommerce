<?php 
  require 'header.php';
 ?>
				<!-- Main container start -->
				<div class="main-container">
					
					<!-- Page header start -->
					<div class="page-header">
						
						<!-- Breadcrumb start -->
						<ol class="breadcrumb">
							<li class="breadcrumb-item">Items List</li>
						</ol>
						<!-- Breadcrumb end -->

						

					</div>
					<!-- Page header end -->
					
					<!-- Row start -->
					<div class="row gutters">
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							<?php if (!isset($_GET['edit'])) {
							 ?>
							<div class="table-container">
								<div class="t-header">Items Data</div>
								<?php 
							if (isset($_GET['delete'])) {
							$delete_id = $_GET['delete'];
							$delete = mysqli_query(connection(),"DELETE FROM banner  WHERE id='$delete_id'");
							if ($delete) {
							echo "<div class='alert alert-success text-center col-lg-4'>Banner No.".$delete_id." has being Deleted Successfully</div>";  
							}
							}
								 ?>
								
								<div class="table-responsive">
									<table id="basicExample" class="table custom-table">
										<thead>
											<tr>
												<th>No.</th>
												<th>Banner Category</th>
												<th>Banner Title</th>
												<th>Banner Discription</th>
												<th>Banner Image</th>
												<th>Edit</th>
												<th>Delete</th>

											</tr>
										</thead>
										<tbody>

										 <?php
										$sele_all_for_admin = mysqli_query(connection(),"SELECT * FROM banner");
										if (mysqli_num_rows($sele_all_for_admin)>0) {
										while ($result = mysqli_fetch_assoc($sele_all_for_admin)) {

						                  ?>
											<tr>
												<td><?php echo $result['id']?></td>
												<td><?php echo substr( $result['banner_cat'],10)?></td>
												<td><?php  echo $result['banner_title']?></td>
												<td><?php  echo substr($result['banner_discription'], 100); ?></td>
												<td><img height="50" width="50" src="img/banners/<?php echo $result['banner_image'] ?>"></td>
												<td><a href="?edit=<?php  echo $result['id']?>"><i class="icon-edit btn btn-info rounded-circle"></i></a></td>
												<td><a href="?delete=<?php  echo $result['id']?>"><i class="icon-trash btn btn-danger rounded-circle"></i></a></td>

											</tr>	
											<?php				
						                }
						                  }
						               ?>
										</tbody>
									</table>
								</div>
							</div>
							<?php 

                             }else if (isset($_GET['edit'])) {
                             	$get_row = $_GET['edit'];
                             $sle = mysqli_query(connection(),"SELECT * FROM banner WHERE id ='$get_row' ");
                              $result = mysqli_fetch_assoc($sle);
                     
							 ?>



							 	<div class="card">
								<div class="card-header">
									<div class="card-title"></div>
								</div>
								<div class="card-body">
                                    <form action="" method="POST" enctype="multipart/form-data">
                                        <div class="row gutters">
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                            	<?php 
										if ($_SERVER['REQUEST_METHOD']=="POST") {
										$file = $_FILES['image'];
										$filename = $file['name'];
										$catholder = $_POST['catholder'];
										$Title = $_POST['title'];
										$Discription = $_POST['Discription'];
										if (empty($catholder) || $catholder=='Choose..' || empty($Title)    || empty($Discription)  && $_FILES['image']['error']==4) {
										   echo "<div class='alert alert-danger text-center'>All Fields Are Required</div>";
										}else{

										$inserter = mysqli_query(connection(),"UPDATE banner SET banner_cat='$catholder',banner_image='$filename',banner_title='$Title',banner_discription='$Discription' WHERE id='$get_row'");
										if ($inserter) {


										move_uploaded_file($file['tmp_name'], "img/banners/".$filename ); 


										echo "<div class='alert alert-success text-center'>Banner has being updated Successfully</div>";
										}

										}
										}
                                            	 ?>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <label class="input-group-text" for="inputGroupSelect01">Categories</label>
                                                        </div>
													<input  maxlength="1" value="<?php echo $result['banner_cat'] ?>" id="cathoder" name="catholder" class=" dropdown-toggle form-control" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          													<div class="dropdown-menu">
						                                        <label class="dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='block'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='none'

						                                        	

						                                        }dropers()">Headlights & lightings</label>
						                                        
						                                        <div class="dropdown-menu hr" id="child">
						                                        	 <h4 class="text-primary">Headlights & lightings</h4>
						                                                <script >
						                                                	
						                                                	hl=['Headlights','Tail Lights','Fog Lights','Turn Signals','Switches & Relays','Corner Lights'];
						                                        	for(i in hl){
						                                        		child.innerHTML+=`<option class="dropdown-item" id="ht${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('ht${i}')
						                                        	input.value=''
						                                        	input.value='Headlights & lightings>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${hl[i]}">${hl[i]}</option>
						                                        <hr>`
						                                        	}
						                                                </script>
															       </div>
															       <label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='block'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='none'

						                                        	


						                                        	

						                                        }dropers()">Interior Parts</label>
						                                        <div class="dropdown-menu hr" id="sechild">
						                                        	 <h4 class="text-primary">Interior Parts</h4>
						                                        	 <script >
						                                        	 	it=['Floor Mats','Gauges','Consoles & Organizers','Mobile Electronics','Steering Wheels','Cargo Accessories'];
						                                        	 	for(i in it){
						                                        		sechild.innerHTML+=`<option class="dropdown-item" id="lo${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('lo${i}')
						                                        	input.value=''
						                                        	input.value='Interior Parts>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${it[i]}">${it[i]}</option>
						                                        <hr>`
						                                        	}
						                                        	 </script>
			
						                                         </div>
                                                                  <label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='block'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='none'

						                                        }dropers()">Tools & Garage</label>
						                                        <div class="dropdown-menu hr" id="thirdchild">
						                                        	 <h4 class="text-primary">Tools & Garage</h4>
			                                                          <script>
			                                                          	
			                                                          	tg=['Repair Manuals','Car Care','Code Readers','Tool Boxes'];

						                                        	for(i in tg){
						                                        		thirdchild.innerHTML+=`<option class="dropdown-item" id="th${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('th${i}')
						                                        	input.value=''
						                                        	input.value='Tools & Garage>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${tg[i]}">${tg[i]}</option>
						                                        <hr>`
						                                        	}
			                                                          </script>
						                                         </div>
                                                                  <label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='block'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='none'

						                                        }dropers()">Brakes & Suspension</label>
						                                        <div class="dropdown-menu hr" id="fourthchild">
						                                        	 <h4 class="text-primary">Brakes & Suspension</h4>
						                                        				<script>
						                                        					bs=['Brake Discs','Wheel Hubs','Air Suspension','Ball Joints','Brake Pad Sets'];

						                                        	for(i in bs){
						                                        	 fourthchild.innerHTML+=`<option class="dropdown-item" id="bg${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('bg${i}')
						                                        	input.value=''
						                                        	input.value='Brakes & Suspension>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${bs[i]}">${bs[i]}</option>
						                                        <hr>`
						                                        	}

						                                        				</script>	
						                                         </div>

                           										<label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='block'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='none'

						                                        }dropers()">Engine & Drivetrain</label>
						                                        <div class="dropdown-menu hr" id="fifthchild">
						                                        	 <h4 class="text-primary">Engine & Drivetrain</h4>
						                                        						<script >
						                                        							ed=['Air Filters','Oxygen Sensors','Heating','Exhaust','Cranks & Pistons'];
						                                        	for(i in ed){
						                                        		fifthchild.innerHTML+=`<option class="dropdown-item" id="e${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('e${i}')
						                                        	input.value=''
						                                        	input.value='Engine & Drivetrain>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${ed[i]}">${ed[i]}</option>
						                                        <hr>`
						                                        	}
						                                        						</script>
						                                         </div>
                                                                 <label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='block'
						                                        	seventhchild.style.display='none'

						                                        }dropers()">Body Parts</label>
						                                        <div class="dropdown-menu hr" id="sixthchild">
						                                        	 <h4 class="text-primary">Body Parts</h4>
					 												<script >
					 													bp=['Bumpers','Hoods','Grilles','Fog Lights','Door Handles','Car Covers','Tailgates'];
					 													wt=['Wheel Covers','Brake Kits','Tire Chains','Wheel disks','Tires','Sensors'];

						                                        	for(i in bp){
						                                        		sixthchild.innerHTML+=`<option class="dropdown-item" id="${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('${i}')
						                                        	input.value=''
						                                        	input.value='Body Parts>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${bp[i]}">${bp[i]}</option>
						                                        <hr>`
						                                        	}

					 												</script>
						                                         </div>
						                                  <label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')


						                                        	child.style.display='none'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='block'


						                                        }dropers()">Wheels & Tires</label>
						                                        <div class="dropdown-menu hr" id="seventhchild">
						                                        	 <h4 class="text-primary">Wheels & Tires</h4>
					 												<script >
					 													wt=['Wheel Covers','Brake Kits','Tire Chains','Wheel disks','Tires','Sensors'];

						                                        	for(i in wt){
						                                        		seventhchild.innerHTML+=`<option class="dropdown-item" id="g${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('g${i}')
						                                        	input.value=''
						                                        	input.value='Wheels & Tires>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${wt[i]}">${wt[i]}</option>
						                                        <hr>`
						                                        	}

					 												</script>
						                                         </div>
						                                        <option class="dropdown-item" id="st" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('st')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"   value="Steering">Steering</option>
						                                        <option class="dropdown-item" id='fs' onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('fs')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Fuel Systems">Fuel Systems</option>
						                                        <option class="dropdown-item" id="t" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('t')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Transmission">Transmission</option>
						                                        <option class="dropdown-item" id='af' onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('af')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Air Filters">Air Filters</option>

						                                        <option class="dropdown-item" id="bpa" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('bpa')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Body Parts">Body Parts</option>

						                                        <option class="dropdown-item" id="c" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('c')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Clutches">Clutches</option>
						                                        
						                                         <option class="dropdown-item" id="s" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('s')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Suspension">Suspension</option>

															</div>
														</div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                              
                                                    <div class="input-group">

                                                        <div class="input-group-append">
                                                            <span class="input-group-text" id="inputGroupFileAddon02">items image</span>
                                                        </div>
                                                        <div class="custom-file">
                                                            <input type="file" accept="image/*" name="image" class="custom-file-input" id="inputGroupFile02">
                                                            <label class="custom-file-label" for="inputGroupFile02" aria-describedby="inputGroupFileAddon02">Choose file</label>
                                                        </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                
                                            </div><br><br><br>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                <div class="form-group">
                                                    <div class="input-group">
                                                       <input type="text" name="title" value="<?php echo $result['banner_title'] ?>" class="form-control" placeholder="Title">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                              
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                <div class="form-group">
                                                    <textarea class="form-control is-vaild" name="Discription" rows="2" placeholder="Discription....."><?php echo $result['banner_discription'] ?></textarea>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">

                                            </div>
                                          
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12 row">
                                                <div class="form-group">
                                                    <button type="submit" name="submit" class="btn btn-primary">Update</button>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12 row">
                                                <div class="form-group">
                                                    <a href="Banners-List" class="btn btn-link">cancle</a>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
								</div>
							</div>
              <?php 
                 }
               ?>
						</div>
					</div>
					<!-- Row end -->

				</div>
				<!-- Main container end -->

				<!-- Container fluid start -->
				<div class="container-fluid">
					<!-- Row start -->
					<div class="row gutters">
						<div class="col-12">
							<!-- Footer start -->
							<div class="footer">
								Copyright motor parts Admin 2020
							</div>
							<!-- Footer end -->
						</div>
					</div>
					<!-- Row end -->
				</div>
				<!-- Container fluid end -->
				
			</div>
			<!-- Page content end -->

		</div>
		<!-- Page wrapper end -->

		<!--**************************
			**************************
				**************************
							Required JavaScript Files
				**************************
			**************************
		**************************-->
		<!-- Required jQuery first, then Bootstrap Bundle JS -->
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/moment.js"></script>


		<!-- *************
			************ Vendor Js Files *************
		************* -->
		<!-- Slimscroll JS -->
		<script src="vendor/slimscroll/slimscroll.min.js"></script>
		<script src="vendor/slimscroll/custom-scrollbar.js"></script>
		
		<!-- Data Tables -->
		<script src="vendor/datatables/dataTables.min.js"></script>
		<script src="vendor/datatables/dataTables.bootstrap.min.js"></script>
		
		<!-- Custom Data tables -->
		<script src="vendor/datatables/custom/custom-datatables.js"></script>
		<script src="vendor/datatables/custom/fixedHeader.js"></script>

		<!-- Download / CSV / Copy / Print -->
		<script src="vendor/datatables/buttons.min.js"></script>
		<script src="js/ads.js"></script>

		<script src="vendor/datatables/jszip.min.js"></script>
		<script src="../../../cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
		<script src="vendor/datatables/vfs_fonts.js"></script>
		<script src="vendor/datatables/html5.min.js"></script>
		<script src="vendor/datatables/buttons.print.min.js"></script>

		<!-- Main JS -->
		<script src="js/main.js"></script>

	</body>

<!-- Mirrored from bootstrap.gallery/tycoon/design-dark-gradient-version/data-tables.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 14 Sep 2020 12:05:57 GMT -->
</html>