<?php 
    include 'header.php';
  ?>
				<!-- Main container start -->
				<div class="main-container">

					<!-- Page header start -->
					<div class="page-header">
						
						<!-- Breadcrumb start -->
						<ol class="breadcrumb">
							<li class="breadcrumb-item">Add Items</li>
						</ol>
						<!-- Breadcrumb end -->
					</div>
					<!-- Page header end -->
					
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title"></div>
								</div>
								<div class="card-body">
                                    <form action="mainserver/add-items" method="POST" enctype="multipart/form-data">
                                        <div class="row gutters">
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                            	<?php 
                                                  if (isset($_GET['error'])) {
                                                  	$error = $_GET['error'];
                                                  	echo $error;
                                                  }elseif (isset($_GET['msg'])) {
                                                  	$msg = $_GET['msg'];
                                                  	echo $msg;
                                                  }
                                            	 ?>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <label class="input-group-text" for="inputGroupSelect01">Categories</label>
                                                        </div>
						                                  
															<input  maxlength="1" value="Choose.." id="cathoder" name="catholder" class=" dropdown-toggle form-control" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                               <div class="dropdown-menu">
						                                        <label class="dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='block'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='none'

						                                        	

						                                        }dropers()">Headlights & lightings</label>
						                                        
						                                        <div class="dropdown-menu hr" id="child">
						                                        	 <h4 class="text-primary">Headlights & lightings</h4>
						                                                <script >
						                                                	
						                                                	hl=['Headlights','Tail Lights','Fog Lights','Turn Signals','Switches & Relays','Corner Lights'];
						                                        	for(i in hl){
						                                        		child.innerHTML+=`<option class="dropdown-item" id="ht${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('ht${i}')
						                                        	input.value=''
						                                        	input.value='Headlights & lightings>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${hl[i]}">${hl[i]}</option>
						                                        <hr>`
						                                        	}
						                                                </script>
															       </div>
															       <label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='block'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='none'

						                                        	


						                                        	

						                                        }dropers()">Interior Parts</label>
						                                        <div class="dropdown-menu hr" id="sechild">
						                                        	 <h4 class="text-primary">Interior Parts</h4>
						                                        	 <script >
						                                        	 	it=['Floor Mats','Gauges','Consoles & Organizers','Mobile Electronics','Steering Wheels','Cargo Accessories','Dashboards','Seat Covers','Floor Mats','Sun Shades','Visors','Car Covers'];
						                                        	 	for(i in it){
						                                        		sechild.innerHTML+=`<option class="dropdown-item" id="lo${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('lo${i}')
						                                        	input.value=''
						                                        	input.value='Interior Parts>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${it[i]}">${it[i]}</option>
						                                        <hr>`
						                                        	}
						                                        	 </script>
			
						                                         </div>
                                                                  <label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='block'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='none'

						                                        }dropers()">Tools & Garage</label>
						                                        <div class="dropdown-menu hr" id="thirdchild">
						                                        	 <h4 class="text-primary">Tools & Garage</h4>
			                                                          <script>
			                                                          	
			                                                          	tg=['Repair Manuals','Car Care','Code Readers','Tool Boxes'];

						                                        	for(i in tg){
						                                        		thirdchild.innerHTML+=`<option class="dropdown-item" id="th${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('th${i}')
						                                        	input.value=''
						                                        	input.value='Tools & Garage>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${tg[i]}">${tg[i]}</option>
						                                        <hr>`
						                                        	}
			                                                          </script>
						                                         </div>
                                                                  <label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='block'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='none'

						                                        }dropers()">Brakes & Suspension</label>
						                                        <div class="dropdown-menu hr" id="fourthchild">
						                                        	 <h4 class="text-primary">Brakes & Suspension</h4>
						                                        				<script>
						                                        					bs=['Brake Discs','Wheel Hubs','Air Suspension','Ball Joints','Brake Pad Sets'];

						                                        	for(i in bs){
						                                        	 fourthchild.innerHTML+=`<option class="dropdown-item" id="bg${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('bg${i}')
						                                        	input.value=''
						                                        	input.value='Brakes & Suspension>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${bs[i]}">${bs[i]}</option>
						                                        <hr>`
						                                        	}

						                                        				</script>	
						                                         </div>

                           										<label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='block'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='none'

						                                        }dropers()">Engine & Drivetrain</label>
						                                        <div class="dropdown-menu hr" id="fifthchild">
						                                        	 <h4 class="text-primary">Engine & Drivetrain</h4>
						                                        						<script >
						                                        							ed=['Air Filters','Oxygen Sensors','Heating','Exhaust','Cranks & Pistons','Timing Belts','Spark Plugs','Oil Pans','Engine Gaskets','Oil Filters','Engine Mounts','Accessories','Timing Belts'];
						                                        	for(i in ed){
						                                        		fifthchild.innerHTML+=`<option class="dropdown-item" id="e${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('e${i}')
						                                        	input.value=''
						                                        	input.value='Engine & Drivetrain>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${ed[i]}">${ed[i]}</option>
						                                        <hr>`
						                                        	}
						                                        						</script>
						                                         </div>
                                                                 <label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='block'
						                                        	seventhchild.style.display='none'

						                                        }dropers()">Body Parts</label>
						                                        <div class="dropdown-menu hr" id="sixthchild">
						                                        	 <h4 class="text-primary">Body Parts</h4>
					 												<script >
					 													bp=['Bumpers','Hoods','Grilles','Fog Lights','Door Handles','Car Covers','Tailgates'];
					 													wt=['Wheel Covers','Brake Kits','Tire Chains','Wheel disks','Tires','Sensors'];

						                                        	for(i in bp){
						                                        		sixthchild.innerHTML+=`<option class="dropdown-item" id="${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('${i}')
						                                        	input.value=''
						                                        	input.value='Body Parts>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${bp[i]}">${bp[i]}</option>
						                                        <hr>`
						                                        	}

					 												</script>
						                                         </div>
						                                  <label class=" dropdown-toggle dropdown-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="function dropers() {
						                                        	child = document.getElementById('child')
						                                        	sechild = document.getElementById('sechild')
						                                        	thirdchild = document.getElementById('thirdchild')
						                                        	fourthchild = document.getElementById('fourthchild')
						                                        	fifthchild = document.getElementById('fifthchild')
						                                        	sixthchild = document.getElementById('sixthchild')
						                                        	seventhchild = document.getElementById('seventhchild')

						                                        	child.style.display='none'
						                                        	sechild.style.display='none'
						                                        	thirdchild.style.display='none'
						                                        	fourthchild.style.display='none'
						                                        	fifthchild.style.display='none'
						                                        	sixthchild.style.display='none'
						                                        	seventhchild.style.display='block'

						                                        }dropers()">Wheels & Tires</label>
						                                        <div class="dropdown-menu hr" id="seventhchild">
						                                        	 <h4 class="text-primary">Wheels & Tires</h4>
					 												<script >
					 													wt=['Wheel Covers','Brake Kits','Tire Chains','Wheel disks','Tires','Sensors'];

						                                        	for(i in wt){
						                                        		seventhchild.innerHTML+=`<option class="dropdown-item" id="g${i}" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('g${i}')
						                                        	input.value=''
						                                        	input.value='Wheels & Tires>'+consumer_elect.value
						                                        }
						                                        consumer_elect()" value="${wt[i]}">${wt[i]}</option>
						                                        <hr>`
						                                        	}

					 												</script>
						                                         </div>
						                                        <option class="dropdown-item" id="st" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('st')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"   value="Steering">Steering</option>
						                                        <option class="dropdown-item" id='fs' onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('fs')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Fuel Systems">Fuel Systems</option>
						                                        <option class="dropdown-item" id="t" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('t')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Transmission">Transmission</option>
						                                        <option class="dropdown-item" id='af' onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('af')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Air Filters">Air Filters</option>

						                                        <option class="dropdown-item" id="bpa" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('bpa')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Body Parts">Body Parts</option>

						                                        <option class="dropdown-item" id="c" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('c')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Clutches">Clutches</option>
						                                        
						                                         <option class="dropdown-item" id="s" onclick="function consumer_elect() {
						                                        	input = document.getElementById('cathoder')
						                                        	consumer_elect = document.getElementById('s')
						                                        	input.value=''
						                                        	input.value=consumer_elect.value
						                                        }
						                                        consumer_elect()"  value="Suspension">Suspension</option>

															</div>
														</div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                <div id="validate" class="form-group text-center text-danger d-block">
                                                   
                                                    <p class="">image should be at least 3 </p>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                <div class="form-group">
                                                	<div class="row" id="displayimage">
                                            		  
                                            		  
                                                   </div>
                                                    <div class="input-group">

                                                        <div class="input-group-append">
                                                            <span class="input-group-text" id="inputGroupFileAddon02">item images</span>
                                                        </div>
                                                        <div class="custom-file">
                                                            <input type="file" accept="image/*" name="image[]" class="custom-file-input" id="inputGroupFile02" multiple>
                                                            <label class="custom-file-label" for="inputGroupFile02" aria-describedby="inputGroupFileAddon02">Choose file</label>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <input type="text" name="Title" class="form-control" placeholder="Title" aria-label="Text input with dropdown button">
                                                    </div>
                                                    <br>
                                                    <div class="custom-file">
                                                    <input type="text" name="Brand" placeholder="Brand" class="form-control" id="">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                              
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                <div class="form-group">
                                                    <textarea class="form-control is-vaild" name="Discription" rows="2" placeholder="Discription....."></textarea>
                                                </div>
                                                 <div class="input-group form-group">
                                                        <div class="input-group-append">
                                                            <span class="input-group-text" id="inputGroupFileAddon02">Item State</span>
                                                        </div>
                                                        
                                                           <select name="p_state" class=" dropdown-toggle form-control col-lg-4">
                                                           	<option selected disabled>Choose..</option>
                                                           	<option value="bestseller">bestseller</option>
                                                           	<option value="popular">popular</option>
                                                           	<option value="none">none</option>

                                                           </select>
                                                    </div>
                                            </div>
                                            
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">

                                            </div><br><br>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                <div class="form-group">

                                                    <div class="input-group">
                                                        <div class="input-group-append">
                                                            <span class="input-group-text" id="inputGroupFileAddon02">NGN</span>
                                                        </div>
                                                        <div class="custom-file">
                                                            <input type="Number" name="amount" placeholder="Price *" class="form-control col-lg-4" id="inputGroupFile02">
                                                        </div>
                                                    </div> <br>
                                                    <label for="checkbox">Availability</label><br><br>
                                                   
                                                    <div class="checkbox">
                                                        <input type="radio"  name="Availability" value="in Stock" id="checkbox" class="checkbox"> In Stock
                                                        <input type="radio" name="Availability" value='Sold' id="checkbox" class="checkbox"> Sold
                                                    </div><br><br>
                                                    <label for="checkbox">Condition</label><br><br>
                                                    <div class="checkbox">
                                                         <input type="radio" name="Condition" value="New" id="checkbox" class="checkbox"> New
                                                        <input type="radio" name="Condition" value='Sale' id="checkbox" class="checkbox">sale
                                                         <input type="radio" name="Condition" value='Hot' id="checkbox" class="checkbox"> Hot
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">

                                            </div>
                                          
                                            <div class="col-xl-6 col-lglg-6 col-md-6 col-sm-12 col-12">
                                                <div class="form-group">
                                                    <button type="submit" name="submit" disabled id="create" class="btn btn-primary">Create</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
								</div>
							</div>
						</div>

				</div>
				<!-- Main container end -->

				<?php include 'footer.php'; ?>
				
			