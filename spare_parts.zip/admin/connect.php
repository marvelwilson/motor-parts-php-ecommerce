<?php
session_start();
 function connection()
{
$hostname='localhost';
$username ='mark Ben';
$password='gotomywebpage';
$db_name = 'eshopper';
	
$con = mysqli_connect($hostname,$username,$password,$db_name) or die('connection was not made');
return $con;
}
 ?>