              
               <?php

              	include 'header.php';
               ?>

				<!-- Main container start -->
				<div class="main-container">

					<!-- Page header start -->
					<div class="page-header">
						
						<!-- Breadcrumb start -->
						<ol class="breadcrumb">
							<li class="breadcrumb-item">Admin Dashboard</li>
						</ol>
						<!-- Breadcrumb end -->


					</div>
					<!-- Page header end -->

					<?php include 'revenue.php' ?>

					<!-- Row start -->
					<div class="row gutters">
						
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Last Added Item</div>
								</div>
								<div class="card-body">
									<ul class="team-activity">
										<li class="product-list clearfix">
											<div class="product-time">

												<p class="date center-text">11:30 am</p>
												<span class="badge badge-info">discription</span>
											</div>
											<div class="product-info">
												<div class="activity">
													<h6>word count(03)</h6>
													<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
													tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
													quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
													consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
													cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
													proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
												</div>
											</div>
										</li>
										<li class="product-list clearfix">
											<div class="product-time">
												<p class="date center-text">11:30 am</p>
												<span class="badge badge-info">image</span>
											</div>
											<div class="product-info">
												<div class="activity">
													<h6>image count(6)</h6>
													<p class="row">
														<img class="p-2"  src="img/user.png" height="50" width="50">
														<img class="p-2"  src="img/user.png" height="50" width="50">
														<img class="p-2"  src="img/user.png" height="50" width="50">
														<img  class="p-2" src="img/user.png" height="50" width="50">
														<img class="p-2"  src="img/user.png" height="50" width="50">
														<img class="p-2"  src="img/user.png" height="50" width="50">

													</p>	
												</div>
											</div>
										</li>
										<li class="product-list clearfix">
											<div class="product-time">
												<p class="date center-text">12:50 pm</p>
												<span class="badge badge-success">views</span>
											</div>
											<div class="product-info">
												<div class="activity">
													<h6>web views</h6>
													<p> amount of view 59 </p>
												</div>
												
													<a class="btn btn-success clearfix" href="item-data/1/edit">Edit</a>
												
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
				</div>
				<!-- Main container end -->

				<?php 
                    include 'footer.php';
				  ?>