function byId(ele) {
	return document.getElementById(ele)
}

fileinput = byId('inputGroupFile02')
validate = byId('validate')
displayimage = byId('displayimage')
create = byId('create')


fileinput.onclick = function () {
	fileinput.setAttribute('accept','image/*')
}

console.log(fileinput)

fileinput.oninput = function () {
	 displayimage.innerHTML=``
	files = fileinput.files
	num = - 1;

	 for (file in files){
        total = num++
        try{
        	 file_type = URL.createObjectURL(files[file])
           displayimage.innerHTML+=`
                            <img  height='50' width='50' src="${file_type}">
                          `
        }catch(e){
        	console.log('forget it')
        }
       
        
	 }
	 console.log(total)
	 if (total < 3) {
	 	validate.removeAttribute('class','text-success')
        validate.setAttribute('class','form-group text-center text-danger d-block text-danger')
       

	 }else{
        validate.removeAttribute('class','text-danger')
        validate.setAttribute('class','form-group text-center  d-block text-success')
         create.removeAttribute('disabled')

	 }
}
