 <?php  
          require '../connect.php';
             
               if ($_SERVER['REQUEST_METHOD']=="POST") {
                     $file = $_FILES['image'];
                     $filename = $file['name'];
                     $catholder = $_POST['catholder'];
                     $Title = $_POST['Title'];
                     $Brand = $_POST['Brand'];
                     $Discription = $_POST['Discription'];
                     $amount = $_POST['amount'];
                     $availability = @$_POST['Availability'];
                     $condition = @$_POST['Condition'];
                     $p_state = @$_POST['p_state'];
                     $quantity = 1;
                     $time = date('h:mi');
                     $date = date('D:M:Y');
                  if (empty($catholder) || $catholder=='Choose..' || empty($Title)  || empty($Brand)  || empty($Discription)  || empty($amount)   || !isset($availability) || !isset($condition) || !isset($p_state)   && $_FILES['image']['error']==4) {
                    header("location:/spare_parts/admin/add-items?error=<div class='alert alert-danger text-center'>All Fields Are Required</div>");
                  }else{
                        $image_array=json_encode($filename);
    $inserter = mysqli_query(connection(),"INSERT INTO product_details(category,title,brand,discription,amount,availability,conditions,quantity,ad_images,time_up,date_up,item_option) VALUES('$catholder','$Title','$Brand','$Discription','$amount','$availability','$condition','$quantity','$image_array','$time','$date','$p_state')");
                     if ($inserter) {
                       
                       foreach( $file[ 'tmp_name' ] as $index => $tmpName )
                          {
                             
                              if( !empty( $tmpName ) && is_uploaded_file( $tmpName ) )
                              {
                              move_uploaded_file($tmpName, "../img/ads/".$file[ 'name' ][ $index ] ); 
                              }
                          }
                           header("location:/spare_parts/admin/add-items?msg=<div class='alert alert-success text-center'>Item has being Created Successfully</div>");
                          }
                           
                  }
                  }
               ?>