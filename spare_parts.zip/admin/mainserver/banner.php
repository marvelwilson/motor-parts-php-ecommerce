 <?php  
  function Create_Banner()
             {
                 if ($_SERVER['REQUEST_METHOD']=="POST") {
                     $file = $_FILES['image'];
                     $filename = $file['name'];
                     $catholder = $_POST['catholder'];
                     $Title = $_POST['Title'];
                     $Discription = $_POST['Discription'];
                  if (empty($catholder) || $catholder=='Choose..' || empty($Title)    || empty($Discription)  && $_FILES['image']['error']==4) {
                   echo "<div class='alert alert-danger text-center'>All Fields Are Required</div>";
                  }else{
                       
    $inserter = mysqli_query(connection(),"INSERT INTO banner(banner_cat,banner_image,banner_title,banner_discription) VALUES('$catholder','$filename','$Title','$Discription')");
                     if ($inserter) {
                       
                       
                          move_uploaded_file($file['tmp_name'], "img/banners/".$filename ); 

                              
                           echo "<div class='alert alert-success text-center'>Banner has being Created Successfully</div>";
                          }
                           
                  }
                  }
             }
 

               ?>