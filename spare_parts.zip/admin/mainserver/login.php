<?php
session_start();
include '../connect.php';
function data_check (){
	$phone = $_POST['phone'];
	$password = md5($_POST['password']);
	if (!preg_match("/^[0-90-9]*$/", $phone)) {
		echo json_encode("invalid");
	}else{

       $checker = mysqli_query(connection(),"SELECT * FROM user_info WHERE phone='$phone' AND password='$password'");
       if (mysqli_num_rows($checker)>0) {
          echo json_encode('found');
          $result_checker = mysqli_fetch_assoc($checker);
          $_SESSION['phone']= $result_checker['phone'];
          $_SESSION['username'] = $result_checker['username'];
          $_SESSION['password'] = $result_checker['password'];
          $_SESSION['user_image'] = $result_checker['user_image'];
       }else{
       	echo json_encode("notfound");
       }
	}
}
if ($_GET['request_type']=='formdata') {
    data_check();
}