<?php
session_start();
include '../connect.php';
function validate_phone()
{
	$phone = $_POST['phone'];

	if (!preg_match("/^[0-90-9 ]*$/", $phone)) {
		echo json_encode("invalid");
	}else{
		echo json_encode("valid");
	}
}
function storage()
{
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $phone = $_POST['phone'];
  $password = $_POST['password'];
  $repeat_pass = $_POST['repeat_pass'];
  $user_image = $_FILES['user_image'];
  $filename = $user_image['name'];
  $file_tmp = $user_image['tmp_name'];
  
 $move = move_uploaded_file($file_tmp, "../img/".$filename);
  $selector = mysqli_query(connection(),"SELECT * FROM user_info WHERE phone='$phone'");
  if ($repeat_pass!==$password) {
    echo json_encode("miss");
  }elseif (mysqli_num_rows($selector)>0) {
    echo json_encode("exist");
 }else{
    echo json_encode("allowed");
  	$_SESSION['firstname'] = $firstname;
  	$_SESSION['lastname'] = $lastname;
  	$_SESSION['phone'] = $phone;
  	$_SESSION['password'] = $password;
    $_SESSION['user_image'] = $filename;

  
  }
}
function check()
{

  @$referal_phone = $_POST['referal_phone'];
  $selector = mysqli_query(connection(),"SELECT * FROM user_info WHERE phone='$referal_phone'");
  if (!preg_match("/^[0-90-9 ]*$/", $referal_phone)) {
    echo json_encode("invalid");
  }elseif (mysqli_num_rows($selector)<1) {
    echo json_encode("invavailable");
 }else{
    echo json_encode("valid");
  }
}
   
function transaction_file()
{
   $referal = $_POST['referal'];
   $file = $_FILES['screenshot'];
  $filename = $file['name'];
  $file_tmp = $file['tmp_name'];
  print_r($_SESSION);
 $move = move_uploaded_file($file_tmp, "../screenshot/".$filename);
   if ($move) {
     $_SESSION["referal_num"] = $referal;
     $_SESSION['screenshot'] = $filename;

   }
 $phone_in = $_SESSION['phone'];
     $access_code =$phone_in[1].$phone_in[4].$phone_in[2].$phone_in[3].$phone_in[0];
     $_SESSION['access_code']=$access_code;

}
function confirm_code()
{
  $code1 = $_POST['code1'];
  $code2 = $_POST['code2'];
  $code3 = $_POST['code3'];
  $code4 = $_POST['code4'];
  $code5 = $_POST['code5'];
  $access_code = $_SESSION['access_code'];
  if ($code1.$code2.$code3.$code4.$code5== $access_code) {
      echo json_encode("allowed");
  $firstname = $_SESSION['firstname'];
  $lastname = $_SESSION['lastname'];
  $phone = $_SESSION['phone'];
  $code = $_SESSION['access_code'];
  $user_image = $_SESSION['user_image'];
  $password = md5($_SESSION['password']);
  $referal_num = $_SESSION['referal_num'];
  $username = $firstname.' '. $lastname;
     $inserter = mysqli_query(connection(),"INSERT INTO user_info(username,phone,referal_num,password,user_image,code) VALUES('$username','$phone','$referal_num','$password','$user_image','$code')");
  
     if ($inserter) {
          $counter = mysqli_query(connection(),"SELECT count(id) FROM user_info WHERE referal_num='$referal_num' ");
                 $referred_users = mysqli_fetch_assoc($counter);
                  $ref = $referred_users['count(id)'];
                  
              $update = mysqli_query(connection(),"UPDATE user_info SET referred='$ref' WHERE phone='$referal_num'");
               }
  }else{
    echo json_encode("incorrect");
  }
}
if (@$_GET['checker']=='phone') {
	validate_phone();
}elseif (@$_GET['checker']=='referal_phone'){
  check();
}elseif (@$_GET['request_type']=='datas') {
	storage();
}else if ($_GET['request_type']=='valdetails') {
   transaction_file();
}else if ($_GET['request_type']=='code') {
  confirm_code();
}