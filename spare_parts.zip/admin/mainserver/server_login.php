<?php
require '../admin/connect.php';
function logfilename($filename)
{
  if (isset($_SESSION['phone'])) {
   header('location:/'.$filename);
 }
 
}

function filename($filename)
{
  if ( ! isset($_SESSION['phone'])) {
   header('location:/'.$filename);
 }
 
}

function login()
{

if (isset($_POST['submit'])) {
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    if (empty($password) || empty($phone)) {
      echo "<div class='alert alert-danger'>fill out the missing field</div>";
    }else{
    $sele_from_admin = mysqli_query(connection(),"SELECT * FROM admin WHERE phone='$phone' AND password='$password'");
    if (mysqli_num_rows($sele_from_admin)>0) {
      if ($_POST['remember_me']=='on') {
        $_SESSION['phone'] = $phone;
        $_SESSION['password'] = $password;
      }
      $_SESSION['phone'] = $phone;
        $_SESSION['password'] = $password;
       header('location:/spare_parts/admin');
    }else{
       echo $_POST['remember_me'];
       echo "<div class='alert alert-danger'>invalid Login Details</div>";
    }
  }
}
}

