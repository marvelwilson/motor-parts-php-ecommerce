<!-- Row start -->
					<div class="row gutters">
						<div class="col-xl-4 col-lg-7 col-md-7 col-sm-7 col-12">
							<div class="info-stats2">
								<div class="info-icon info">
									<i class="icon-eye1"></i>
								</div>
								<div class="sale-num">
									<h3>32,589</h3>
									<p>Visitors</p>
								</div>
							</div>
						</div>
						<div class="col-xl-4 col-lg-7 col-md-7 col-sm-7 col-12">
							<div class="info-stats2">
								<div class="info-icon danger">
									<i class="icon-shopping-cart1"></i>
								</div>
								<div class="sale-num">
									<h3>27,837</h3>
									<p>Orders</p>
								</div>
							</div>
						</div>
						<div class="col-xl-4 col-lg-7 col-md-7 col-sm-7 col-12">
							<div class="info-stats2">
								<div class="info-icon warning">
									<i class="icon-shopping-bag1"></i>
								</div>
								<div class="sale-num">
									<h3>43,456</h3>
									<p>Sales</p>
								</div>
							</div>
						</div>
					</div>
					<!-- Row end -->